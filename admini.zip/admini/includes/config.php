<?php
    $db=mysqli_connect("localhost","root","","ciphervote") or die("connectivity failed");
?>
<?php
	session_start();
	include 'includes/conn.php';

    if ($_SESSION['key']!= "AdminKey")
    {
		session_destroy();
		session_unset();
		?>
	<script>
		location.assign("../index.php");
	</script>
	<?php
       
    }

?>
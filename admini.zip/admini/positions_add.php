<?php
	include 'includes/session.php';

	if(isset($_POST['add'])){
		$description = $_POST['description'];
		$starting_time = $_POST['starting_time'];
		$ending_time = $_POST['ending_time'];

		$sql = "SELECT * FROM positions ORDER BY priority DESC LIMIT 1";
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();

		$priority = $row['priority'] + 1;
		date_default_timezone_set('Asia/Kolkata'); // Set the default time zone to India
		$current_time = time(); // Get the current Unix timestamp
		$inserted_at = date("Y-m-d H:i:s", $current_time); // Convert Unix timestamp to formatted date string

		$time1 = new DateTime($inserted_at); // Convert $inserted_at to a DateTime object
		$time2 = new DateTime($starting_time); // Convert $starting_time to a DateTime object
		$time3 = new DateTime($ending_time); // Convert $ending_time to a DateTime object
		if($time3 <= $time2)
		{
			$_SESSION['error'] = 'Ending Time must be atleast 1 minute after Starting Time';
		}
		else
		{

		if ($time3 < $time1) {
			$status = "Expired"; // Ending time is before current time
		} elseif ($time2 > $time1) {
			$status = "Inactive"; // Starting time is in the future
		} else {
			$status = "Active"; // Starting time is in the past and ending time is in the future
		}

		



		
		$sql = "INSERT INTO positions (description, priority, starting_time, ending_time,status) VALUES ('$description', '$priority', '$starting_time', '$ending_time', '$status')";

		if($conn->query($sql)){
			$_SESSION['success'] = 'Election added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}

	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: positions.php');
?>
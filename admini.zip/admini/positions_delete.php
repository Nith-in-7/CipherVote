<?php
	include 'includes/session.php';

	if(isset($_POST['delete'])){
		$id = $_POST['id'];
		$sql = "DELETE FROM positions WHERE id = '$id'";
		$sqa="DELETE FROM candidates WHERE position_id = '$id'";
		$sqm="DELETE FROM votes WHERE position_id = '$id'";
		if($conn->query($sql) and $conn->query($sqa) and $conn->query($sqm))
		{
			$_SESSION['success'] = 'Election deleted successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	else{
		$_SESSION['error'] = 'Select item to delete first';
	}

	header('location: positions.php');
	
?>
<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$description = $_POST['description'];
		$starting_time = $_POST['starting_time'];
		$ending_time = $_POST['ending_time'];
		date_default_timezone_set('Asia/Kolkata'); // Set the default time zone to India
		$current_time = time(); // Get the current Unix timestamp
		$inserted_at = date("Y-m-d H:i:s", $current_time); // Convert Unix timestamp to formatted date string

		$time1 = new DateTime($inserted_at); // Convert $inserted_at to a DateTime object
		$time2 = new DateTime($starting_time); // Convert $starting_time to a DateTime object
		$time3 = new DateTime($ending_time); // Convert $ending_time to a DateTime object
		if($time3 <= $time2)
		{
			$_SESSION['error'] = 'Ending Time must be atleast 1 minute after Starting Time';
		}
		else
		{

		if ($time3 < $time1) {
			$status = "Expired"; // Ending time is before current time
		} elseif ($time2 > $time1) {
			$status = "Inactive"; // Starting time is in the future
		} else {
			$status = "Active"; // Starting time is in the past and ending time is in the future
		}



		$sql = "UPDATE positions SET description = '$description', starting_time = '$starting_time', ending_time = '$ending_time',status='$status' WHERE id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Election updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}
	}
	}
	else{
		$_SESSION['error'] = 'Fill up edit form first';
	}

	header('location: positions.php');

?>
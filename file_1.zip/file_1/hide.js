$(function() {
    setTimeout(function() { $("#hideDiv").fadeOut(500); }, 2500)
    
    })
$(function()
 {
    setTimeout(function() { $("#hideDivotp").fadeOut(500); }, 2500)
        
 })
$(function()
 {
    setTimeout(function() { $("#hideDivyellow").fadeOut(500); }, 2500)
        
 })
 
$(function()
 {
    setTimeout(function() { $("#hideDivotpgreen").fadeOut(500); }, 2500)
        
 })




    
    

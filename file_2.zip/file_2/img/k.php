<?php session_start() ?>
<?php 
    require_once("admin/inc/config.php");

    $fetchingElections = mysqli_query($db, "SELECT * FROM elections") OR die(mysqli_error($db));
    while($data = mysqli_fetch_assoc($fetchingElections))
    {
        $stating_date = $data['starting_date'];
        $ending_date = $data['ending_date'];
        $curr_date = date("Y-m-d");
        $election_id = $data['id'];
        $status = $data['status'];

      

        if($status == "Active")
        {
            $date1=date_create($curr_date);
            $date2=date_create($ending_date);
            $diff=date_diff($date1,$date2);
            
            if((int)$diff->format("%R%a") < 0)
            {
            
                mysqli_query($db, "UPDATE elections SET status = 'Expired' WHERE id = '". $election_id ."'") OR die(mysqli_error($db));
            }
        }else if($status == "InActive")
        {
            $date1=date_create($curr_date);
            $date2=date_create($stating_date);
            $diff=date_diff($date1,$date2);
            

            if((int)$diff->format("%R%a") <= 0)
            {
                
                mysqli_query($db, "UPDATE elections SET status = 'Active' WHERE id = '". $election_id ."'") OR die(mysqli_error($db));
            }
        }
        

    }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
    <link rel="stylesheet" href="assets/css/login.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="assets/css/style.css?v=<?php echo time(); ?>">
   
  
    <title>CIPHERVOTE</title>
  </head>

                <?php 
                    if(isset($_GET['sign-up']))
                    {
                ?>
                <div class="container h-100">
		<div class="d-flex justify-content-center h-100">
			<div class="user_card">
				<div class="d-flex justify-content-center">
					<div class="brand_logo_container">
						<img src="assets/images/logo.jpeg" class="brand_logo" alt="Logo">
					</div>
				</div>

                        <div class="d-flex justify-content-center form_container">
                            <form method="POST">
                                <div class="input-group mt-4">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    </div>
                                    <input type="text" name="su_username" class="form-control input_user" placeholder="Admission No" required />
                                </div>
                                <div class="input-group mt-2">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                                    </div>
                                    <input type="text" name="su_contact_no" class="form-control input_pass" placeholder="Email Id" required />
                                </div>
                                <div class="input-group mt-2">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                                    </div>
                                    <input type="password" name="su_password" class="form-control input_pass" placeholder="Password" required />
                                </div>     
                                <div class="input-group mt-2">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                                    </div>
                                    <input type="password" name="su_retype_password" class="form-control input_pass" placeholder="Retype Password" required />
                                </div>
                                
                                    <div class="d-flex justify-content-center mt-3 login_container">
                            <button type="submit" name="sign_up_btn" class="btn">Sign Up</button>
                        </div>
                            </form>
                        </div>
                
                        <div class="mt-4">
                            <div class="d-flex justify-content-center links text-black">
                                Already Created Account? <a href="index.php" class="ml-2 text-blue">Sign In</a>
                            </div>
                        </div>
                <?php
                    }
                    else if(isset($_GET['otpsent'])) {
                        ?>
                             <div class="container">
                                <div class="forms-container">
                                    <div class="signin-signup">
                                    <form  method="POST"  class="sign-in-form">
                                    <h2 class="title">Validation</h2>
                                        
                                       
                                        <div class="input-field">
                                        <i class="fas fa-lock"></i>
                                        <input type="text" id="otp" class="form-control" name="otp_code" placeholder="OTP" required autofocus>
                                        </div>
                                        
                                        
                                        <button type="submit" name="verifybtn" class="btn login_btn">Validate OTP</button>
                                    
                                        
                                        
                                    </form>
                                    <form method="POST" class="sign-up-form">
                                    <h2 class="title">Sign in</h2>
                                        <div class="input-field">
                                        <i class="fas fa-envelope"></i>
                                        <input type="text" name="contact_no" class="form-control input_user" placeholder="Email" required />
                                        </div>
                                        <div class="input-field">
                                        <i class="fas fa-lock"></i>
                                        <input type="password" name="password" class="form-control input_pass" placeholder="Password" required />
                                        </div>
                                        <div >
                                                        <button type="submit" name="loginBtn" class="btn login_btn">Login</button>
                                                    </div>
                                    
                                    </form>
                                    </div>
                                </div>

                                <div class="panels-container">
                                    <div class="panel left-panel">
                                    <div class="content">
                                        <h1>Completed Validation ?</h1>
                                        <p>
                                        
                                        
                                                </p>
                                        <button class="btn transparent" id="sign-up-btn">
                                        Sign in
                                        </button>
                                    </div>
                                    <img src="img/signup.svg" class="image" alt="" />
                                    </div>
                                    <div class="panel right-panel">
                                    <div class="content">
                                        <h1>New here ?</h1>
                                        <p>
                                        Enter your details to create a free account
                                        </p>
                                        <button class="btn transparent" id="sign-in-btn">
                                        Sign Up
                                        </button>
                                    </div>
                                    <img src="img/login.svg" class="image" alt="" />
                                    </div>
                                </div>
                                </div>
                                <script src="app.js"></script>
                            </body>

                        <?php
                    }else {
                ?>
                    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
        <form  method="POST"  class="sign-in-form">
        <h2 class="title">Validation</h2>
        <div class="input-field"> <i class="fas fa-lock"></i><input type="text" id="otp" class="form-control" name="otp_code" placeholder="OTP" required autofocus></div>
        <button type="submit" name="verifybtn" class="btn login_btn">Validate OTP</button>
        </form>
          <form method="POST" class="sign-up-form">
          <h2 class="title">Sign in</h2>
            <div class="input-field">
              <i class="fas fa-envelope"></i>
              <input type="text" name="contact_no" class="form-control input_user" placeholder="Email" required />
            </div>
            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" name="password" class="form-control input_pass" placeholder="Password" required />
            </div>
            <div >
                            <button type="submit" name="loginBtn" class="btn login_btn">Login</button>
                        </div>
           
          </form>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h1>One of us ?</h1>
            <p>
            Enter your login credentials to access CipherVote
              
                    </p>
            <button class="btn transparent" id="sign-up-btn">
              Sign in
            </button>
          </div>
          <img src="img/signup.svg" class="image" alt="" />
        </div>
        <div class="panel right-panel">
          <div class="content">
            <h1>New here ?</h1>
            <p>
            Enter your details to create a free account
            </p>
            <button class="btn transparent" id="sign-in-btn">
              Sign Up
            </button>
          </div>
          <img src="img/login.svg" class="image" alt="" />
        </div>
      </div>
    </div>
    <script src="app.js"></script>
    <div id="errorMessage" class="bg-white text-danger text-center mt-2" style="display: none;"></div>

<script>
$(document).ready(function(){
    $("#loginBtn").click(function(){
        var contact_no = $("#contact_no").val();
        var password = $("#password").val();
        $.ajax({
            type: "POST",
            url: "validate_login.php",
            data: {
                contact_no: contact_no,
                password: password
            },
            success: function(response){
                if(response == "success") {
                    window.location.href = "homepage.html"; // Redirect to homepage upon successful login
                } else {
                    $("#errorMessage").html(response).show(); // Display error message
                }
            }
        });
    });
});
</script>

  </body>


  
                <?php
                    }
                     
                ?>

                <?php 
                    if(isset($_GET['otpfailed']))
                    {
                ?>
                        <span class="bg-white text-danger text-center mt-1"> OTP sending failed! </span>
                <?php
                    }else if(isset($_GET['invalid'])) {
                ?>
                        <span class="bg-white text-danger text-center mt-1"> Passwords mismatched, please try again! </span>
                <?php
                
                    }else if(isset($_GET['wrongotp'])) {
                        ?>
                            <div class="mt-3">
                                <div class="d-flex justify-content-center links text-danger">
                                     Invalid OTP <a href="?sign-up=1" class="ml-3 text-blue">Sign Up again</a>
                                </div>
                            </div>
                        <?php
                        
                    }else if(isset($_GET['successful'])) {
                        ?>
                             <div class="mt-3">
                            <div class="d-flex justify-content-center links text-success">
                                Account Created successfully <a href="index.php" class="ml-2 text-blue">Sign In</a>
                            </div>
                        </div>
                        <?php
                        
                    }
                    else if(isset($_GET['not_registered'])) {
                        ?>
                                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                                <script src="hide.js"></script>
                                 <div id="hideDivyellow"><b>Email not registered</div></b>
                        <?php
                            
                    }else if(isset($_GET['admissionno'])) {
                        ?>
                                <span class="bg-white text-danger text-center mt-2 "> Invalid Admission Number </span>
                        <?php
                            }
                   
                    else if(isset($_GET['weak'])) {
                        ?>
                                <span class="bg-white text-danger text-center mt-2 mb-0">Password must have an uppercase, a lowercase, a number and a special character </span>
                        <?php
                    }else if(isset($_GET['length'])) {
                        ?>
                                <span class="bg-white text-danger text-center mt-2">Password must have at least 8 characters </span>
                        <?php
                    }else if(isset($_GET['user_exist'])) {
                        ?>
                                <span class="bg-white text-danger text-center mt-2">Email already registered </span>
                        <?php
                    }
                    else if(isset($_GET['email'])) {
                        ?>
                                <span class="bg-white text-danger text-center mt-2">Use JECC Email id </span>
                        <?php
                    }
                ?>
                       
			</div>
		</div>
	</div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>

<?php 
    require_once("admin/inc/config.php");

    if(isset($_POST['sign_up_btn']))
    {
        $su_username = mysqli_real_escape_string($db, $_POST['su_username']);
        $su_contact_no = mysqli_real_escape_string($db, $_POST['su_contact_no']);
        $su_pass = mysqli_real_escape_string($db,($_POST['su_password']));
        $su_password = mysqli_real_escape_string($db, sha1($_POST['su_password']));
        $su_retype_password = mysqli_real_escape_string($db, sha1($_POST['su_retype_password']));
        $user_role = "Voter"; 
        $_SESSION['username'] =  $su_username;
        $_SESSION['email'] =  $su_contact_no;
        $_SESSION['password'] =  $su_password;
        $_SESSION['userrole'] = $user_role;
        $password_pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';
        $emailsample="@jecc.ac.in";
        $check_query = mysqli_query($db, "SELECT * FROM users where contact_no ='$su_contact_no'");
        $rowCount = mysqli_num_rows($check_query);

        if($rowCount > 0){
            ?>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                <script src="hide.js"></script>
                <div id="hideDiv"><b>Email already registered</div></b>
            
            <?php
        }
        else{
            if(!preg_match("/^[0-9]*$/",$su_username) OR strlen($su_username)!=8)
            {
             ?> 
              <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
              <script src="hide.js"></script>
                  <div id="hideDiv"><b>
                    Invalid Admission Number
                 </div></b>
              
            <?php 
            }
            else{
                if(strpos($su_contact_no,$emailsample)!==false )
                {

                    if(strlen($su_pass)<8)
                    {
                        ?> 
               <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
              <script src="hide.js"></script>
                  <div id="hideDiv"><b>
                    Password must have atleast 8 characters
                 </div></b>
              
            <?php

                    }
                    else{
                        if (preg_match($password_pattern, $su_pass))
                        {

                            if($su_password == $su_retype_password )
                            {
                                $otp = rand(100000,999999);
                                $_SESSION['otp'] = $otp;
                                $_SESSION['mail'] = $su_contact_no;
                                require "Mail/phpmailer/PHPMailerAutoload.php";
                                $mail = new PHPMailer;
                
                                $mail->isSMTP();
                                $mail->Host='smtp.gmail.com';
                                $mail->Port=587;
                                $mail->SMTPAuth=true;
                                $mail->SMTPSecure='tls';
                
                                $mail->Username='ciphervote@gmail.com';
                                $mail->Password='ibipxhaiioxstnlp';
                
                                $mail->setFrom('ciphervote@gmail.com', 'OTP Verification');
                                $mail->addAddress($_POST["su_contact_no"]);
                
                                $mail->isHTML(true);
                                $mail->Subject="Your verification code";
                                $mail->Body="<p>Dear user, </p> <h3>Your verification code to access CipherVote is $otp <br></h3>
                                <br><br>
                                <p>With regrads,</p>
                                Team Ciphervote";
                
                                        if(!$mail->send()){
                                            ?>
                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                                                <script src="hide.js"></script>
                                                 <div id="hideDiv"><b>
                                                    OTP sending failed !
                                                 </div></b>
                                            <?php
                                        }else{
                                             ?>
                                                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                                                <script src="hide.js"></script>
                                                 <div id="hideDivgreen"><b>
                                                    OTP has been sent successfully
                                                 </div></b>
                                                    <script>location.assign("index.php?otpsent=1");</script>
                                             <?php
                                        }
                                

                            

                            }else {
                        ?>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                            <script src="hide.js"></script>
                            <div id="hideDiv"><b> Passwords doesn't match </div></b>
                                
                        <?php
                            }
                        }
                        else {
                            ?>
                                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                                <script src="hide.js"></script>
                                <div id="hideDiv"><b> Password must have an uppercase , a lower case , a number and a special character </div></b>
                            <?php
                                }
                            }
                        }
                else
                {
                    ?>
                         <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                            <script src="hide.js"></script>
                            <div id="hideDiv"><b>Use JECC Email</div></b>
                    <?php

                }
            }
        }       
    }else if(isset($_POST['loginBtn']))
    {
        $contact_no = mysqli_real_escape_string($db, $_POST['contact_no']);
        $password = mysqli_real_escape_string($db, sha1($_POST['password']));
        

        
        $fetchingData = mysqli_query($db, "SELECT * FROM users WHERE contact_no = '". $contact_no ."'") or die(mysqli_error($db));

        
        if(mysqli_num_rows($fetchingData) > 0)
        {
            $data = mysqli_fetch_assoc($fetchingData);

            if($contact_no == $data['contact_no'] AND $password == $data['password'])
            {
            
                $_SESSION['user_role'] = $data['user_role'];
                $_SESSION['username'] = $data['username'];
                $_SESSION['user_id'] = $data['id'];
                
                if($data['user_role'] == "Admin")
                {
                    $_SESSION['key'] = "AdminKey";
            ?>
                    <script> location.assign("admin/index.php?homepage=1"); </script>
            <?php
                }else {
                    $_SESSION['key'] = "VotersKey";
            ?>
                    <script> location.assign("voters/index.php"); </script>
            <?php
                }

            }else {
                ?>
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                            <script src="hide.js"></script>
                            <div id="hideDiv"><b>Email or password incorrect</div></b>
                 <?php
            }


        }
        else
         {
         ?>
               
               <script> location.assign("index.php?not_registered=1"); </script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                <script src="hide.js"></script>
                <div id="hideDivyellow"><b>Email not registered</div></b>
         <?php

        }

    }
    else if(isset($_POST["verifybtn"])){
       
        $su_username=$_SESSION['username']  ;
        $su_contact_no=$_SESSION['email'] ;
        $su_password=$_SESSION['password'] ;
        $user_role=$_SESSION['userrole'] ;
        $otp_code = $_POST['otp_code'];
        $otp = $_SESSION['otp'];
        if($otp != $otp_code){
            ?>
                 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                 <script src="hide.js"></script>
                 <div id="hideDivotp"><b>Invalid OTP</div></b>
           <?php
        }else{
           
            mysqli_query($db, "INSERT INTO users(username, contact_no, password, user_role) VALUES('". $su_username ."', '". $su_contact_no ."', '". $su_password ."', '". $user_role ."')") or die(mysqli_error($db));
            session_destroy();
            ?>
             <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
             <script src="hide.js"></script>
             <div id="hideDivotpgreen"><b> Account registered successfully </div></b>
             <?php
        }

    }

?>
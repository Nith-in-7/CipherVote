<?php
	include 'includes/conn.php';
	session_start();
    if($_SESSION['key'] != "VotersKey")
    {
        echo "<script> location.assign('../admini/logout.php'); </script>";
        die;
    }
	else
	{
		$sql = "SELECT * FROM users WHERE id = '".$_SESSION['voter']."'";
		$query = $conn->query($sql);
		$voter = $query->fetch_assoc();
	}
?>